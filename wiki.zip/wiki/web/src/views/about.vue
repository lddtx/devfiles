<template>
  <div class="about">
    <h1>关于我们</h1>
  </div>
</template>
