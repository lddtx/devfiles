import { createStore } from 'vuex'

declare let SessionStorage: any;
const USER = "USER";

const store = createStore({
  state: {
    // 从SessionStore中获取，如果获取不到就返回空对象，防止空指针异常
    user: SessionStorage.get(USER) || {}
  },
  mutations: {
    setUser(state, user) {
      // 登录成功后不仅对全局变量进行赋值，还存在SessionStorage中
      state.user = user;
      SessionStorage.set(USER, user);
    }
  },
  actions: {
  },
  modules: {
  }
});

export default store;