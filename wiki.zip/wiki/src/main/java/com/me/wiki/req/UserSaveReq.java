package com.me.wiki.req;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.StringJoiner;

public class UserSaveReq {
    private Long id;

    @NotEmpty(message = "【登录名】不能为空！")
    private String loginName;

    @NotEmpty(message = "【昵称】不能为空！")
    private String name;

    @NotEmpty(message = "【密码】不能为空！")
    @Pattern(regexp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,32}$", message = "【密码】至少包含 数字和英文，长度6-32")
    private String password;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", UserSaveReq.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("loginName='" + loginName + "'")
                .add("name='" + name + "'")
                .add("password='" + password + "'")
                .toString();
    }
}