package com.me.wiki.app;

import com.me.wiki.req.DocQueryReq;
import com.me.wiki.req.DocSaveReq;
import com.me.wiki.resp.DocQueryResp;
import com.me.wiki.resp.CommonResp;
import com.me.wiki.resp.PageResp;
import com.me.wiki.service.DocService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;

@RestController
public class DocController {

    @Resource
    private DocService docService;

    @GetMapping("/doc/all/{ebookId}")
    public CommonResp<List<DocQueryResp>> all(@PathVariable Long ebookId) {
        CommonResp<List<DocQueryResp>> resp = new CommonResp<>();
        List<DocQueryResp> docQueryRespList = docService.all(ebookId);
        resp.setContent(docQueryRespList);
        return resp;
    }

    @GetMapping("/doc/list")
    public CommonResp<PageResp<DocQueryResp>> list(@Valid DocQueryReq req) {
        CommonResp<PageResp<DocQueryResp>> resp = new CommonResp<>();
        PageResp<DocQueryResp> docQueryResp = docService.findByName(req);
        resp.setContent(docQueryResp);
        return resp;
    }

    @PostMapping("/doc/save")
    public CommonResp<Object> save(@Valid @RequestBody DocSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        docService.save(req);
        return resp;
    }

    @DeleteMapping("/doc/delete/{ids}")
    public CommonResp<Object> delete(@PathVariable("ids") String ids) {
        CommonResp<Object> resp = new CommonResp<>();
        List<String> idList = Arrays.asList(ids.split(","));
        docService.delete(idList);
        return resp;
    }

    @GetMapping("/doc/find-content/{id}")
    public CommonResp<String> findContent(@PathVariable("id") Long id) {
        CommonResp<String> resp = new CommonResp<>();
        String content = docService.findContent(id);
        resp.setContent(content);
        return resp;
    }

    @GetMapping("/doc/vote/{id}")
    public CommonResp<Object> vote(@PathVariable("id") Long id) {
        CommonResp<Object> commonResp = new CommonResp<>();
        docService.vote(id);
        return commonResp;
    }
}
