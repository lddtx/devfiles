package com.me.wiki.mapper;

import com.me.wiki.domain.Test;

import java.util.List;

public interface TestMapper {

    public List<Test> list();
}
