package com.me.wiki.app;

import com.me.wiki.req.EbookQueryReq;
import com.me.wiki.req.EbookSaveReq;
import com.me.wiki.resp.CommonResp;
import com.me.wiki.resp.EbookQueryResp;
import com.me.wiki.resp.PageResp;
import com.me.wiki.service.EbookService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

@RestController
public class EbookController {

    @Resource
    private EbookService ebookService;

    @GetMapping("/ebook/list")
    public CommonResp<PageResp<EbookQueryResp>> list(@Valid EbookQueryReq req) {
        CommonResp<PageResp<EbookQueryResp>> resp = new CommonResp<>();
        PageResp<EbookQueryResp> ebookQueryResp = ebookService.findByName(req);
        resp.setContent(ebookQueryResp);
        return resp;
    }

    @PostMapping("/ebook/save")
    public CommonResp<Object> save(@Valid @RequestBody EbookSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        ebookService.save(req);
        resp.setSuccess(true);
        return resp;
    }

    @DeleteMapping("/ebook/delete/{id}")
    public CommonResp<Object> delete(@PathVariable("id") Long id) {
        CommonResp<Object> resp = new CommonResp<>();
        ebookService.delete(id);
        resp.setSuccess(true);
        return resp;
    }
}
