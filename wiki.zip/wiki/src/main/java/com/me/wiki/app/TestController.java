package com.me.wiki.app;

import com.me.wiki.domain.Demo;
import com.me.wiki.domain.Ebook;
import com.me.wiki.domain.Test;
import com.me.wiki.resp.CommonResp;
import com.me.wiki.service.DemoService;
import com.me.wiki.service.EbookService;
import com.me.wiki.service.TestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

@RestController
public class TestController {

    private static final Logger LOG = LoggerFactory.getLogger(TestController.class);

    @Value("${hello.world:TEST}")
    private String hello;

    @Resource
    private TestService testService;

    @Resource
    private DemoService demoService;

    @Resource
    private EbookService ebookService;

    @Resource
    private RedisTemplate redisTemplate;

    @GetMapping("hello")
    public String hello() {
        return "hello world!" + hello;
    }

    @GetMapping("/test/list")
    public List<Test> list() {
        return testService.list();
    }

    @GetMapping("/test/demo")
    public List<Demo> demoList() {
        return demoService.list();
    }

    @GetMapping("/test/ebook")
    public CommonResp<List<Ebook>> ebookList() {
        CommonResp<List<Ebook>> resp = new CommonResp<>();
        List<Ebook> ebookList = ebookService.list();
        resp.setContent(ebookList);
        return resp;
    }
    @GetMapping("/redis/set/{key}/{value}")
    public String set(@PathVariable Long key, @PathVariable String value) {
        redisTemplate.opsForValue().set(key, value, 3600, TimeUnit.SECONDS);
        LOG.info("key: {}, value: {}", key, value);
        return "success";
    }

    @GetMapping("/redis/get/{key}")
    public Object get(@PathVariable Long key) {
        Object object = redisTemplate.opsForValue().get(key);
        LOG.info("key: {}, value: {}", key, object);
        return object;
    }

}
