package com.me.wiki.resp;

import java.util.List;
import java.util.StringJoiner;

public class PageResp<T> {

    private long total;

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    private List<T> list;

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", PageResp.class.getSimpleName() + "[", "]")
                .add("total=" + total)
                .add("list=" + list)
                .toString();
    }
}