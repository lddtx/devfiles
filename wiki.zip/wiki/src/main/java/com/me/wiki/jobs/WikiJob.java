package com.me.wiki.jobs;

import com.me.wiki.service.DocService;
import com.me.wiki.utils.SnowFlake;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class WikiJob {

    private static final Logger LOG = LoggerFactory.getLogger(WikiJob.class);

    @Resource
    private DocService docService;

    @Resource
    private SnowFlake snowFlake;

    /**
     * 自定义cron表达式
     * 只有等上一次执行完毕，下一次才会在下一个时间点执行，错过就错过
     * 每分钟的5秒，35秒...执行
     */
    @Scheduled(cron = "5/30 * * * * ?")
    public void updateEbookByCron() {
        // 增加日志流水号
        MDC.put("LOG_ID", String.valueOf(snowFlake.nextId()));
        LOG.info("更新电子书信息开始...");
        long start = System.currentTimeMillis();
        docService.updateEbookInfo();
        LOG.info("更新电子书信息耗时：{}ms", (System.currentTimeMillis() - start));

    }
}
