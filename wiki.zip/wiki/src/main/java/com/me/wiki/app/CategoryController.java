package com.me.wiki.app;

import com.me.wiki.req.CategoryQueryReq;
import com.me.wiki.req.CategorySaveReq;
import com.me.wiki.resp.CategoryQueryResp;
import com.me.wiki.resp.CommonResp;
import com.me.wiki.resp.PageResp;
import com.me.wiki.service.CategoryService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

@RestController
public class CategoryController {

    @Resource
    private CategoryService categoryService;

    @GetMapping("/category/all")
    public CommonResp<List<CategoryQueryResp>> all() {
        CommonResp<List<CategoryQueryResp>> resp = new CommonResp<>();
        List<CategoryQueryResp> categoryQueryRespList = categoryService.all();
        resp.setContent(categoryQueryRespList);
        return resp;
    }

    @GetMapping("/category/list")
    public CommonResp<PageResp<CategoryQueryResp>> list(@Valid CategoryQueryReq req) {
        CommonResp<PageResp<CategoryQueryResp>> resp = new CommonResp<>();
        PageResp<CategoryQueryResp> categoryQueryResp = categoryService.findByName(req);
        resp.setContent(categoryQueryResp);
        return resp;
    }

    @PostMapping("/category/save")
    public CommonResp<Object> save(@Valid @RequestBody CategorySaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        categoryService.save(req);
        resp.setSuccess(true);
        return resp;
    }

    @DeleteMapping("/category/delete/{id}")
    public CommonResp<Object> delete(@PathVariable("id") Long id) {
        CommonResp<Object> resp = new CommonResp<>();
        categoryService.delete(id);
        resp.setSuccess(true);
        return resp;
    }
}
