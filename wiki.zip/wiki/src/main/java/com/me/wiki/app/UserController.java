package com.me.wiki.app;

import com.alibaba.fastjson.JSONObject;
import com.me.wiki.req.UserLoginReq;
import com.me.wiki.req.UserQueryReq;
import com.me.wiki.req.UserResetPasswordReq;
import com.me.wiki.req.UserSaveReq;
import com.me.wiki.resp.CommonResp;
import com.me.wiki.resp.UserLoginResp;
import com.me.wiki.resp.UserQueryResp;
import com.me.wiki.resp.PageResp;
import com.me.wiki.service.UserService;
import com.me.wiki.utils.SnowFlake;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.concurrent.TimeUnit;

@RestController
public class UserController {

    private static final Logger LOG = LoggerFactory.getLogger(UserController.class);

    @Resource
    private UserService userService;

    @Resource
    private RedisTemplate redisTemplate;

    @Resource
    private SnowFlake snowFlake;

    @GetMapping("/user/list")
    public CommonResp<PageResp<UserQueryResp>> list(@Valid UserQueryReq req) {
        CommonResp<PageResp<UserQueryResp>> resp = new CommonResp<>();
        PageResp<UserQueryResp> userQueryResp = userService.findByName(req);
        resp.setContent(userQueryResp);
        return resp;
    }

    @PostMapping("/user/save")
    public CommonResp<Object> save(@Valid @RequestBody UserSaveReq req) {
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        CommonResp<Object> resp = new CommonResp<>();
        userService.save(req);
        resp.setSuccess(true);
        return resp;
    }

    @DeleteMapping("/user/delete/{id}")
    public CommonResp<Object> delete(@PathVariable("id") Long id) {
        CommonResp<Object> resp = new CommonResp<>();
        userService.delete(id);
        resp.setSuccess(true);
        return resp;
    }

    @PostMapping("/user/reset-password")
    public CommonResp<Object> resetPassword(@Valid @RequestBody UserResetPasswordReq req) {
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        CommonResp<Object> resp = new CommonResp<>();
        userService.resetPassword(req);
        resp.setSuccess(true);
        return resp;
    }

    @PostMapping("/user/login")
    public CommonResp<UserLoginResp> login(@Valid @RequestBody UserLoginReq req) {
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        CommonResp<UserLoginResp> resp = new CommonResp<>();
        UserLoginResp userLoginResp = userService.login(req);
        // 生成单点登录token
        Long token = snowFlake.nextId();
        userLoginResp.setToken(token.toString());
        LOG.info("单点登录生成的token：{}", token);
        redisTemplate.opsForValue().set(token.toString(), JSONObject.toJSONString(userLoginResp),
                3600 * 24, TimeUnit.SECONDS);
        resp.setContent(userLoginResp);
        resp.setSuccess(true);
        return resp;
    }

    @GetMapping("/user/logout/{token}")
    public CommonResp<Object> logout(@PathVariable("token") String token) {
        CommonResp<Object> resp = new CommonResp<>();
        redisTemplate.delete(token);
        LOG.info("从redis中删除token: {}", token);
        resp.setSuccess(true);
        return resp;
    }
}
