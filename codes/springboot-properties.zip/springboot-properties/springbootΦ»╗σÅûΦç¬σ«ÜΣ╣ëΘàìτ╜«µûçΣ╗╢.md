#### 前言

我们在开发springboot的项目过程中，为了不把所有的配置信息全都写在application.(yml/properties)中，我们需要自定义配置文件比如common.properties，那么问题来了，我们要如何读取common.properties里面的内容。

也许有人会说那还不简单，直接写个读取配置文件工具类来读取不就行了。这样确实可以满足需求，但有没有更优雅的读取方法，比如用springboot提供的@Value注解就可以取到配置信息，而非用PropertiesUtil.getProperty("xxx")方式来获取。

答案是有的，以下介绍两种方案实现用@value来获取自定义配置文件

#### 第一种方案，利用@PropertySource注解来实现

@PropertySource可以用来加载指定的配置文件，默认它只能加载*.properties文件，不能加载诸如yaml等文件。

@PropertySource相关属性介绍
-   value：指明加载配置文件的路径。 
    
-   ignoreResourceNotFound：指定的配置文件不存在是否报错，默认是false。当设置为 true 时，若该文件不存在，程序不会报错。实际项目开发中，最好设置 ignoreResourceNotFound 为 false。 
    
-   encoding：指定读取属性文件所使用的编码，我们通常使用的是UTF-8。

示例
```Java
@Data
@AllArgsConstructor   
@NoArgsConstructor   
@Builder
@Configuration
@PropertySource(value = {"classpath:common.properties"},ignoreResourceNotFound=false,encoding="UTF-8")
@ConfigurationProperties(prefix = "author")
public class Author {
	private String name;  
	private String job;
    private String sex;
}
```

对于@ConfigurationProperties注解。@ConfigurationProperties会根据配置文件的信息调用声明对象的set方法，这样调用toString的时候，对象的属性就不为空了，我们可以使用@ConfigurationProperties 中的 prefix 用来指明我们配置文件中需要注入信息的前缀

前边提到了用@PropertySource只能加载*.properties文件，但如果我们项目的配置文件不是*.properties这种类型，而是其他类型，诸如yaml，此时我们可以通过实现PropertySourceFactory接口，重写createPropertySource方法，就能实现用@PropertySource也能加载yaml等类型文件。

```Java
package com.learn.factory;  
  
import org.apache.commons.lang3.StringUtils;  
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;  
import org.springframework.core.env.PropertiesPropertySource;  
import org.springframework.core.env.PropertySource;  
import org.springframework.core.io.support.EncodedResource;  
import org.springframework.core.io.support.PropertySourceFactory;  
import java.io.FileNotFoundException;  
import java.io.IOException;  
import java.util.Properties;  
  
public class YamlPropertySourceFactory implements PropertySourceFactory {  
 @Override  
 public PropertySource<?> createPropertySource(String sourceName, EncodedResource 			 					     		resource) throws IOException {  
		 Properties propertiesFromYaml = loadYaml(resource);  
				if(StringUtils.isBlank(sourceName)){  
		 			sourceName =  resource.getResource().getFilename();;  
				}  

		 return new PropertiesPropertySource(sourceName, propertiesFromYaml);  
    }  
 private Properties loadYaml(EncodedResource resource) throws FileNotFoundException {  
 try {  
		 YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();  
					factory.setResources(resource.getResource());  
					factory.afterPropertiesSet();  
					return factory.getObject();  
        } catch (IllegalStateException e) {  
		 	// for ignoreResourceNotFound  
			 Throwable cause = e.getCause();  
						if (cause instanceof FileNotFoundException)  
			 throw (FileNotFoundException) e.getCause();  
						throw e;  
				}  
		 }
}
```

使用：

```Java
package com.learn.model;  
  
import com.learn.factory.YamlPropertySourceFactory;  
import lombok.AllArgsConstructor;  
import lombok.Builder;  
import lombok.Data;  
import lombok.NoArgsConstructor;  
import org.springframework.boot.context.properties.ConfigurationProperties;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.context.annotation.PropertySource;  
  
@Data  
@AllArgsConstructor  
@NoArgsConstructor  
@Builder  
@Configuration  
@PropertySource(factory = YamlPropertySourceFactory.class, value = {"classpath:user.yml"},  
        ignoreResourceNotFound=false, encoding="UTF-8")  
@ConfigurationProperties(prefix = "user")  
public class User {  
 	private String username;  
    private String password;  
}
```

#### 第二种方案，使用EnvironmentPostProcessor加载自定义配置文件

需要在META-INF下创建spring.factories

```Java
package com.learn.env;  
  
import lombok.extern.slf4j.Slf4j;  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.env.EnvironmentPostProcessor;  
import org.springframework.core.env.ConfigurableEnvironment;  
import org.springframework.core.env.PropertiesPropertySource;  
  
import java.io.IOException;  
import java.io.InputStreamReader;  
import java.util.Properties;  
  
@Slf4j  
public class CustomEnvironmentPostProcessor implements EnvironmentPostProcessor {  
 @Override  
 public void postProcessEnvironment(ConfigurableEnvironment environment, 	SpringApplication application) {  
  
 Properties properties = new Properties();  
  
        try {  
 properties.load(new InputStreamReader(CustomEnvironmentPostProcessor.class.getClassLoader().getResourceAsStream("custom.properties"),"UTF-8"));  
  
            PropertiesPropertySource propertiesPropertySource = new PropertiesPropertySource("custom",properties);  
            environment.getPropertySources().addLast(propertiesPropertySource);  
        } catch (IOException e) {  
 log.error(e.getMessage(),e);  
        }  
  
 }}
```

spring.factories内容：
>org.springframework.boot.env.EnvironmentPostProcessor=com.learn.env.CustomEnvironmentPostProcessor

测试：

```Java
package com.learn;  
  
import com.learn.model.Author;  
import com.learn.model.User;  
import lombok.extern.slf4j.Slf4j;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.boot.ApplicationArguments;  
import org.springframework.boot.ApplicationRunner;  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  

@SpringBootApplication  
@Slf4j  
public class PropertiesApplication implements ApplicationRunner {  
  
	@Autowired  
	private Author author;  
  
    @Autowired  
 	private User user;  
  
    //@Value("#{}")表示SpEl表达式通常用来获取bean的属性，或者调用bean的某个方法
 	@Value("#{author.name}")  
 	private String name;  
  
    @Value("${author.job}")  
 	private String job;  
  
    @Value("${author.sex}")  
 	private String sex;  
  
    @Value("${author.url}")  
 	private String authorUrl;  
  
    @Value("${author.hobby}")  
 	private String authorHobby;  
  
    public static void main(String[] args) {  
 		SpringApplication.run(PropertiesApplication.class,args);  
    }  
  
	@Override  
	public void run(ApplicationArguments args) {  
		System.out.println(author);  
		log.info("name:{}---nickName:{}", name, author.getNickName());  
		System.out.println(authorUrl);  
		System.out.println(job);  
		System.out.println(sex);  
		System.out.println(authorHobby);  
		System.out.println(user);  
	}  
}
```

在注释掉@ConfigurationProperties(prefix = "author")的情况下，不会执行set方法，Author对象的属性值皆为空，而直接使用@Value的情况下，直接使用配置文件中的属性key(author.属性)可以取到，说明@ConfigurationProperties只是调用set方法，并不能简化@Value的取值，也就是省略前缀。
<h2>
	<img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210830155735.png"/>
</h2>