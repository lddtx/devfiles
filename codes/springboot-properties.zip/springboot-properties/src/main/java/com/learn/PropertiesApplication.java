package com.learn;

import com.learn.model.Author;
import com.learn.model.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@Slf4j
public class PropertiesApplication implements ApplicationRunner {

    @Autowired
    private Author author;

    @Autowired
    private User user;

    //@Value("#{}")表示SpEl表达式通常用来获取bean的属性，或者调用bean的某个方法。当然还有可以表示常量
    @Value("#{author.name}")
    private String name;

    @Value("${author.job}")
    private String job;

    @Value("${author.sex}")
    private String sex;

    @Value("${author.url}")
    private String authorUrl;

    @Value("${author.hobby}")
    private String authorHobby;

    public static void main(String[] args) {
        SpringApplication.run(PropertiesApplication.class,args);
    }

    @Override
    public void run(ApplicationArguments args) {
        System.out.println(author);
        log.info("name:{}---nickName:{}", name, author.getNickName());
        System.out.println(authorUrl);
        System.out.println(job);
        System.out.println(sex);
        System.out.println(authorHobby);
        System.out.println(user);
    }
}
