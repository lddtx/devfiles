package com.learn;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class PropertiesTest {

    @DynamicPropertySource
    public static void overrideProps(DynamicPropertyRegistry registry) {
        registry.add("author.home", () -> "china");
        registry.add("author.tel", () -> "+86");
    }

    @Value("${author.home}")
    private String authorHome;

    @Value("${author.tel}")
    private String authorTel;

    @Test
    public void testProperties() throws Exception {
        System.out.println(authorHome);
        System.out.println(authorTel);
    }
}
