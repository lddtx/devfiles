### Redisson
[项目地址](https://github.com/redisson/redisson/tree/master/redisson-spring-boot-starter)

Maven
```xml
     <dependency>
         <groupId>org.redisson</groupId>
         <artifactId>redisson-spring-boot-starter</artifactId>
         <version>3.16.1</version>
     </dependency>
```

redisson-spring-data版本问题 `redisson-spring-data` 对应的spring boot版本:

|redisson-spring-data<br/>module name|Spring Boot<br/>version|
|----------------------------|-------------------|
|redisson-spring-data-16     |1.3.x              |
|redisson-spring-data-17     |1.4.x              |
|redisson-spring-data-18     |1.5.x              |
|redisson-spring-data-20     |2.0.x              |
|redisson-spring-data-21     |2.1.x              |
|redisson-spring-data-22     |2.2.x              |
|redisson-spring-data-23     |2.3.x              |
|redisson-spring-data-24     |2.4.x              |
|redisson-spring-data-25     |2.5.x              |

spring boot 设置:

```yaml
spring:
  redis:
    database: 
    host:
    port:
    password:
    ssl: 
    timeout:
    cluster:
      nodes:
    sentinel:
      master:
      nodes:
```

Redisson 配置:

```yaml
spring:
  redis:
   redisson: 
      file: classpath:redisson.yml
      config: |
        clusterServersConfig:
          idleConnectionTimeout: 10000
          connectTimeout: 10000
          timeout: 3000
          retryAttempts: 3
          retryInterval: 1500
          failedSlaveReconnectionInterval: 3000
          failedSlaveCheckInterval: 60000
          password: null
          subscriptionsPerConnection: 5
          clientName: null
          loadBalancer: !<org.redisson.connection.balancer.RoundRobinLoadBalancer> {}
          subscriptionConnectionMinimumIdleSize: 1
          subscriptionConnectionPoolSize: 50
          slaveConnectionMinimumIdleSize: 24
          slaveConnectionPoolSize: 64
          masterConnectionMinimumIdleSize: 24
          masterConnectionPoolSize: 64
          readMode: "SLAVE"
          subscriptionMode: "SLAVE"
          nodeAddresses:
          - "redis://127.0.0.1:7004"
          - "redis://127.0.0.1:7001"
          - "redis://127.0.0.1:7000"
          scanInterval: 1000
          pingConnectionInterval: 0
          keepAlive: false
          tcpNoDelay: false
        threads: 16
        nettyThreads: 32
        codec: !<org.redisson.codec.MarshallingCodec> {}
        transportMode: "NIO"

```

带密码的redis配置
```yaml
singleServerConfig:
  address: "redis://admin@127.0.0.1:6379"
  connectTimeout: 10000
```