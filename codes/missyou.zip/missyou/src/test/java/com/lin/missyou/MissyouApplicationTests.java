package com.lin.missyou;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MissyouApplicationTests {

    @Test
    void contextLoads() {
    }

}
