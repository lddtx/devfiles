public class ChildWiget extends Wiget{
    @Override
    public synchronized void doSomething() {
        super.doSomething();
        System.out.println("end");
    }

    public static void main(String[] args) {
        Wiget wiget = new ChildWiget();
        wiget.doSomething();
    }
}
