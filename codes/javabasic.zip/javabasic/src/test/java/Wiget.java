public class Wiget {
    public synchronized void doSomething(){
        System.out.println("begin");
    }
}
