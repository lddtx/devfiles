import java.lang.management.ManagementFactory;
import java.util.concurrent.TimeUnit;

public class PidGet {
    public static void main(String[] args) {
        String name = ManagementFactory.getRuntimeMXBean().getName();
        String s = name.split("@")[0];
        System.out.println("pid: " + s);

        while (true){
            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("process");
        }
    }
}
