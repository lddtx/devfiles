public interface Kings {
    void doSomething();
}
