public abstract class Others implements Kings{

}
