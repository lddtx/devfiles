package com.interview.javabasic.thread;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class FutureTaskDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        FutureTask<String> task = new FutureTask<>(new MyCallable());
        new Thread(task).start();
        // isDone()方法用于判断Callable的call()方法是否执行完成了
        if(!task.isDone()){
            System.out.println("task has not finished, please wait!");
        }
        // 阻塞直到能取到返回值
        System.out.println("task return: " + task.get());
    }
}
