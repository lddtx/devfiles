package com.interview.javabasic.construct.array;

public class Fruit {
    private String name;
    private float price;

    public Fruit(String name, float price){
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Fruit{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
