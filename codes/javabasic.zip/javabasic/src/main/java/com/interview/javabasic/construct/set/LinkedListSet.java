package com.interview.javabasic.construct.set;

import com.interview.javabasic.construct.link.LinkedList;

public class LinkedListSet<T> implements Set<T> {

    private LinkedList<T> list;

    public LinkedListSet(){
        list = new LinkedList<>();
    }

    @Override
    public void add(T e) {
        // 确保不能添加重复的元素
        if (!list.contains(e)){
            list.addFirst(e);
        }
    }

    @Override
    public void remove(T e) {
        list.removeElement(e);
    }

    @Override
    public boolean contains(T e) {
        return list.contains(e);
    }

    @Override
    public int getSize() {
        return list.getSize();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }
}
