package com.interview.javabasic.bytecode;

public class StackLeakByThread {
    public static void stackLeakByThread(){
        while (true){
            new Thread(() -> {
                while (true){
                }
            }).start();
        }
    }

    public static void main(String[] args) {
        stackLeakByThread();
    }
}
