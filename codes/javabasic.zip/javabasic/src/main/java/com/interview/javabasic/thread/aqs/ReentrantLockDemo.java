package com.interview.javabasic.thread.aqs;

import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockDemo implements  Runnable{
    private static ReentrantLock lock = new ReentrantLock(false);
    static int count = 0;
    @Override
    public void run(){
        try{
            lock.lock();
            for (int i = 0; i < 10000; i++) {
                count++;
            }
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        ReentrantLockDemo rld = new ReentrantLockDemo();
        Thread thread1 = new Thread(rld);
        Thread thread2 = new Thread(rld);
        thread1.start();
        thread2.start();
        thread1.join();
        thread2.join();
        System.out.println(count);
    }
}
