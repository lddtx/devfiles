package com.interview.javabasic.construct.array;

public class Main {
    public static void main(String[] args) {
        Array<Integer> array = new Array<>();
        for (int i = 0; i < 20; i++) {
            array.addLast(i);
        }
        System.out.println(array);

        array.add(1, 1000);
        System.out.println(array);

        array.remove(1);
        System.out.println(array);

        array.addLast(2);
        System.out.println(array);

        array.removeLast();
        System.out.println(array);

        Array<Fruit> fruitArray = new Array<>();
        Fruit banana = new Fruit("香蕉", (float) 2.98);
        fruitArray.addLast(new Fruit("橘子", (float) 3.98));
        fruitArray.addLast(new Fruit("苹果", (float) 8.98));
        fruitArray.addLast(banana);
        System.out.println(fruitArray);
        fruitArray.removeElement(banana);
        System.out.println(fruitArray);
    }
}
