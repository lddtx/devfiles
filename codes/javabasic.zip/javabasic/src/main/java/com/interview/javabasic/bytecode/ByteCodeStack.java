package com.interview.javabasic.bytecode;

public class ByteCodeStack {
    public static int add(int a, int b){
        int c = 0;
        c = a + b;
        return c;
    }
}
