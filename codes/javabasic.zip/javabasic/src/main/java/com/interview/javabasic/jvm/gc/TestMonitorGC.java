package com.interview.javabasic.jvm.gc;

public class TestMonitorGC {
    private static final int _1MB = 1024*1024;

    public static void main(String[] args) {
        byte[] allocations1, allocations2,allocations3,allocations4;

        allocations1 = new byte[2*_1MB];
        allocations2 = new byte[2*_1MB];
        allocations3 = new byte[2*_1MB];
        allocations4 = new byte[4*_1MB];
    }
}
