package com.interview.javabasic.reflect;

public class ClassLoaderChecker {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        //MyClassLoader m = new MyClassLoader("/Users/zhouguangping/Documents/javabasic/src/com/interview/javabasic/reflect/", "myClassLoader");
        MyClassLoader m = new MyClassLoader("/Users/zhouguangping/Desktop/", "myClassLoader");
        // 这里有包名时，必须加上
        //Class c = m.loadClass("com.interview.javabasic.reflect.Robot");
        Class c = m.loadClass("wali");
        System.out.println(c.getClassLoader());
        System.out.println(c.getClassLoader().getParent());
        System.out.println(c.getClassLoader().getParent().getParent());
        c.newInstance();
    }
}
