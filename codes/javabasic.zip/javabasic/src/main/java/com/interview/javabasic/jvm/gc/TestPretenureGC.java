package com.interview.javabasic.jvm.gc;

public class TestPretenureGC {
    private static final int _1MB = 1024*1024;

    public static void main(String[] args) {
        byte[] allocations;
        // 直接分配到老年代中
        allocations = new byte[4*_1MB];
    }
}
