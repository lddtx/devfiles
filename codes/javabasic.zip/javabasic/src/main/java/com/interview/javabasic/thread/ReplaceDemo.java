package com.interview.javabasic.thread;

public class ReplaceDemo {
    public static void main(String[] args) {
        String a = "The beautiful girl's boy friend is Jack";
        String b = "The beautiful girl often chats with Jack";
        String c = "The beautiful girl loves Jack so much";
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
}
