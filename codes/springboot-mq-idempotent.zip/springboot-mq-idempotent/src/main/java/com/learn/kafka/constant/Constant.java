package com.learn.kafka.constant;


public class Constant {
    public static final String TOPIC = "msgTopic";

    public static final String TOPIC_KEY_PREFIX = "test_";
}
