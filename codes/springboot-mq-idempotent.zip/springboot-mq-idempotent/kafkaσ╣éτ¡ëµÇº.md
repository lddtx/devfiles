Docker配置Kafka
zookeeper镜像：wurstmeister/zookeeper
kafka镜像：wurstmeister/kafka

<h2>
	<img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210829162144.png"/>
</h2>

启动Zookeeper容器
<h2>
	<img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210829162615.png"/>
</h2>

设置kafka启动参数：
ifconfig查看本机IP
```xml
en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
	options=400<CHANNEL_IO>
	ether f0:18:98:b4:7a:f7
	inet6 fe80::1c2d:5cb2:c753:9ea1%en0 prefixlen 64 secured scopeid 0xe
	inet 192.168.31.142 netmask 0xffffff00 broadcast 192.168.31.255
	nd6 options=201<PERFORMNUD,DAD>
	media: autoselect
	status: active
```

KAFKA_ZOOKEEPER_CONNECT=192.168.31.142:2181
KAFKA_ADVERTISED_HOST_NAME=192.168.31.142:2181
端口绑定：
9092:9092
<h2>
	<img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210829165647.png"/>
</h2>

测试是否启动成功：
```bash
$KAFKA_HOME/bin/kafka-topics.sh --create --zookeeper 192.168.31.142:2181 --replication-factor 1 --partitions 1 --topic test
```

<h2>
	<img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210829170621.png"/>
</h2>

查看所有Topic
```bash
$KAFKA_HOME/bin/kafka-topics.sh --list --zookeeper 192.168.31.142:2181
```

查看Topic详情：
```bash
$KAFKA_HOME/bin/kafka-topics.sh --describe --topic test --zookeeper 192.168.31.142:2181
```

启动生产者：
```bash
$KAFKA_HOME/bin/kafka-console-producer.sh --topic=test --broker-list 192.168.31.142:9092
```

 新开窗口启动消费者：
```bash
$KAFKA_HOME/bin/kafka-console-consumer.sh --bootstrap-server 192.168.31.142:9092 --topic test --from-beginning
```

<h2>
	<img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210829171746.png"/>
</h2>