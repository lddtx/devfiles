### Spring Data Jpa
[视频](https://www.youtube.com/watch?v=wuX2ESOy-Ts)
#### H2数据库配置
<h3 align = "center">
    <img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210826224854.png"/>
</h3>

#### 数据库连接
<h3 align = "center">
    <img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210826224933.png"/>
</h3>

#### 数据库
<h3 align = "center">
    <img src="https://gitee.com/zhouguangping/image/raw/master/markdown/20210826225023.png"/>
</h3>