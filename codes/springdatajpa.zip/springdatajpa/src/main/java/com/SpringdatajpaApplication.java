package com;

import com.entity.Employee;
import com.repository.EmployeeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringdatajpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringdatajpaApplication.class, args);
    }

    @Bean
    public CommandLineRunner run(EmployeeRepository employeeRepository) {
        return (args -> {
            //insert(employeeRepository);
            System.out.println(employeeRepository.findAll());
            System.out.println(employeeRepository.findEmployeeByNameContaining("J"));
        });
    }

    public void insert(EmployeeRepository employeeRepository) {
        employeeRepository.save(new Employee("King"));
        employeeRepository.save(new Employee("Jam"));
        employeeRepository.save(new Employee("Mark"));
        employeeRepository.save(new Employee("John"));
    }
}
