package base.sort;

import base.sort.normal.BobbleSort;
import base.sort.normal.InsertionSort;
import base.sort.normal.SelectionSort;
import base.sort.other.BucketSort;
import base.sort.separate.MergeSort;
import base.sort.separate.QuickSortImmutable;
import base.sort.separate.QuickSortMutable;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SortTest {

    @Test
    void insertionSortTest() {
        sort(InsertionSort.class, 100000);
    }

    @Test
    void selectionSortTest() {
        sort(SelectionSort.class, 100000);
    }

    @Test
    void bobbleSortTest() {
        sort(BobbleSort.class, 100000);
    }

    @Test
    void mergeSortTest() {
        sort(MergeSort.class, 100000);
    }

    @Test
    void quickImmutableSortTest() {
        sort(QuickSortImmutable.class, 100000);
    }

    @Test
    void quickSortTestMutableTest() {
        sort(QuickSortMutable.class, 100000);
    }

    @Test
    void bucketSortTest() {
        var bucketSort = new BucketSort();
        var l = new ArrayList<Integer>();

        for (int i = 0; i < 100000; i++) {
            l.add((int)(Math.random() * 100));
        }
        var start = System.currentTimeMillis();
        List<Integer> A = bucketSort.sort(l);
        System.out.println("耗时：" + (System.currentTimeMillis() - start));
        System.out.println(A.subList(0, 2000));
        assertSorted(A);
    }

    @SuppressWarnings("all")
    public void sort(Class cls, int no) {
        try {
            var constructor = cls.getConstructor();
            var instance = constructor.newInstance();
            var start = System.currentTimeMillis();
            if (instance instanceof IImmutableSorter) {
                var A = gen(no);
                var sorter = (IImmutableSorter)instance;
                A = sorter.sort(A);
                System.out.println("耗时：" + (System.currentTimeMillis() - start));
                assertSorted(A);
                System.out.println(A.subList(0, 20));
            } else if (instance instanceof IMutableSorter) {
                var A = gen(no).stream().mapToInt(x -> x).toArray();
                var sorter = (IMutableSorter)instance;
                sorter.sort(A);
                System.out.println("耗时：" + (System.currentTimeMillis() - start));
                assertSorted(A);
                System.out.println(Arrays.stream(Arrays.copyOfRange(A, 0, 20)).boxed().collect(Collectors.toList()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static List<Integer> gen(int no) {
        var A = new ArrayList<Integer>();
        for (int i = 0; i < no; i++) {
            A.add((int) (Math.random() * no));
        }
        return A;
    }

    static void assertSorted(int[] checkInts) {
        assertSorted(Arrays.stream(checkInts).boxed().collect(Collectors.toList()));
    }

    @SuppressWarnings("all")
    static void assertSorted(List<Integer> checkList) {
        Integer min = Integer.MIN_VALUE;
        for (Integer ele : checkList) {
            if (min > ele) {
                System.out.println(checkList.toString());
                System.out.println("未完全排序！！！");
            }
            min = ele;
        }
    }
}
