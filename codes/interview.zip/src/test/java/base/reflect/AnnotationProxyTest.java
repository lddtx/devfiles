package base.reflect;

import base.reflect.annotation.ObjectFactory;
import base.reflect.annotation.IOrder;
import base.reflect.annotation.Order;
import org.junit.jupiter.api.Test;

import java.lang.reflect.InvocationTargetException;

public class AnnotationProxyTest {
    @Test
    void annotationProxyTest() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException, InterruptedException {
        IOrder order = ObjectFactory.newInstance(Order.class);

        order.pay();
        order.show();;
    }
}
