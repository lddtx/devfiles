package base.reflect;

import base.reflect.annotation.ObjectFactory;
import base.reflect.proxy.IAspect;
import base.reflect.proxy.IOrder;
import base.reflect.proxy.Order;
import org.junit.jupiter.api.Test;

import java.lang.reflect.InvocationTargetException;

public class ProxyTest {
    @Test
    void proxyTest() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException, InterruptedException {
        IOrder order = IAspect.getProxy(Order.class, "base.reflect.proxy.TimeUsageAspect");

        order.pay();
        order.show();
    }
}
