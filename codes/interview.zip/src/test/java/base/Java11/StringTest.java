package base.Java11;

import org.junit.jupiter.api.Test;

public class StringTest {
    @Test
    void stringTest1() {
        System.out.println(" ".isBlank());

        // "Foo Bar"
        System.out.println(" Foo Bar ".strip());
        // " Foo Bar"
        System.out.println(" Foo Bar ".stripTrailing());
        // "Foo Bar "
        System.out.println(" Foo Bar ".stripLeading());

        // "JavaJavaJava"
        System.out.println("Java".repeat(3));

        // 3
        System.out.println("A\nB\nC".lines().count());
    }
}
