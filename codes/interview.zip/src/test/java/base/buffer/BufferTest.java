package base.buffer;

import org.junit.jupiter.api.Test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.CompletionHandler;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class BufferTest {
    @Test
    void gen() throws IOException {
        Random r = new Random();
        var fileName = "文本.txt";
        var fout = new FileOutputStream(fileName);
        var start = System.currentTimeMillis();
        // 频繁写入，性能差，百万、千万
        for (int i = 0; i < 1000000; i++) {
            for (int j = 0; j < 5; j++) {
                fout.write(97 + r.nextInt(5));
            }
        }
        fout.close();
        System.out.println(System.currentTimeMillis() - start);
    }

    @Test
    void genByBuffer() throws IOException {
        Random r = new Random();
        var fileName = "文本.txt";
        var bufferSize = 4 * 1024;
        var fout = new BufferedOutputStream(new FileOutputStream(fileName), bufferSize);
        var start = System.currentTimeMillis();
        // 使用buffer后性能有大提升
        for (int i = 0; i < 1000000; i++) {
            for (int j = 0; j < 5; j++) {
                fout.write(97 + r.nextInt(5));
            }
            // 单词用空格分开
            fout.write(32);
        }
        fout.close();
        System.out.println(System.currentTimeMillis() - start);
    }

    @Test
    void read() throws IOException {
        var fileName = "文本.txt";
        var fint = new FileInputStream(fileName);

        var start = System.currentTimeMillis();
        int b;
        while ((b = fint.read()) != -1) {
        }
        fint.close();
        System.out.println(System.currentTimeMillis() - start);
    }

    @Test
    void readByBuffer() throws IOException {
        var fileName = "文本.txt";
        // buffer的默认bufferSize为8192，可以自定义
        var fint = new BufferedInputStream(new FileInputStream(fileName));

        var start = System.currentTimeMillis();
        int b;
        // 不再单字节字节地读，而是8k8k地读
        var bytes = new byte[1024 * 8];
        while ((b = fint.read(bytes)) != -1) {
        }
        fint.close();
        System.out.println(System.currentTimeMillis() - start);
    }

    /**
     * nio并不是一定比普通io的buffer快，而是更加简便，
     * 不需要指定过多的对象，比如bytes
     */
    @Test
    void readByNio() throws IOException {
        var fileName = "文本.txt";
        var channel = new FileInputStream(fileName).getChannel();
        // channel是一种编程模型规范，读写都是用buffer实现，需要提供buffer
        var buffer = ByteBuffer.allocate(8 * 1024); // 8k
        var start = System.currentTimeMillis();

        while (channel.read(buffer) != -1) {
            // 切换成读模式
            buffer.flip();
            // 读取数据
            // System.out.println(new String(buffer.array()));

            // 读完再写，需清空掉缓冲区
            buffer.clear();
        }
        System.out.println(System.currentTimeMillis() - start);

        channel.close();
    }

    /**
     * 异步channel
     */
    @Test
    void readByAsync() throws IOException, ExecutionException, InterruptedException {
        var fileName = "文本.txt";
        var channel = AsynchronousFileChannel.open(Path.of(fileName),
                StandardOpenOption.READ);

        var buffer = ByteBuffer.allocate(8 * 1024);
        Future<Integer> operation = channel.read(buffer, 0);

        while (!operation.isDone()) {
            var numReads = operation.get();
            buffer.flip();
            var chars = new String(buffer.array());
            System.out.println(chars);
            buffer.clear();
        }

        channel.close();
    }

    @Test
    void readByAsync2() throws IOException {
        var fileName = "文本.txt";
        var channel = AsynchronousFileChannel.open(Path.of(fileName),
                StandardOpenOption.READ);

        var buffer = ByteBuffer.allocate(8 * 1024);
        channel.read(buffer, 0, buffer, new CompletionHandler<>() {
            @Override
            public void completed(Integer result, ByteBuffer attachment) {
                attachment.flip();
                var chars = new String(buffer.array());
                System.out.println(chars);
                attachment.clear();
            }

            @Override
            public void failed(Throwable exc, ByteBuffer attachment) {
                System.out.println("failed");
            }
        });
    }
}
