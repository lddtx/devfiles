package base.buffer;

import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

public class questionTest {

    final ForkJoinPool pool = ForkJoinPool.commonPool();

    /**
     * 读取中文的字节问题
     */
    @Test
    void chineseTest() {
        var raw = "床前明月光，疑是地上霜，举头望明月，低头思故乡";
        var charset = StandardCharsets.UTF_8;
        byte[] bytes = charset.encode(raw).array();
        // 读出部分数据
        byte[] partOfBytes = Arrays.copyOfRange(bytes, 0, 14);

        var byteBuffer = ByteBuffer.allocate(16);
        var charBuffer = CharBuffer.allocate(16);

        byteBuffer.put(partOfBytes);
        // 开始从byteBuffer中读取数据
        byteBuffer.flip();

        // 从byteBuffer中读取数据，输出结果写入到charBuffer中
        // 注意：在有无法解析的字符的时候，例如读到半个中文字节，charBuffer不会去读
        charset.newDecoder().decode(byteBuffer, charBuffer, true);

        // 开始从charBuffer中读取数据
        charBuffer.flip();

        var tmp = new char[charBuffer.length()];
        // 判断是否还有可用数据
        if (charBuffer.hasRemaining()) {
            charBuffer.get(tmp);
            System.out.println(new String(tmp));
        }

        // 是否有数据未读取出来，也就是charBuffer识别不了的字节
        System.out.format("limit - position = %d\n", byteBuffer.limit() - byteBuffer.position());

        // 读取剩余的字节内容
        byte[] leftOfBytes = Arrays.copyOfRange(byteBuffer.array(), byteBuffer.position(), byteBuffer.limit());
        System.out.println(Arrays.toString(leftOfBytes));
    }

    /**
     * 统计词频
     */
    @Test
    void countWordsTest() throws IOException {
        var in = new BufferedInputStream(new FileInputStream("文本.txt"));
        var bytes = new byte[1024 * 1024];
        int len;
        var total = new HashMap<String, Integer>();
        var start = System.currentTimeMillis();
        while ((len = in.read(bytes)) != -1) {
            // 最后一次读取会读不满给定读长度，这里拷贝一下
            var partOfBytes = Arrays.copyOfRange(bytes, 0, len);
            var str = new String(partOfBytes);
            var countMap = countByString(str);
            for (var entry : countMap.entrySet()) {
                var word = entry.getKey();
                incKey(total, word, entry.getValue());
            }
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - start));
        System.out.println(total.get("abcde"));
        System.out.println(total.size());
    }

    private static HashMap<String, Integer> countByString(String str) {
        var countMap = new HashMap<String, Integer>();
        // 使用内置的StringTokenizer计算单词数，有句号、逗号或者是空格就会断句
        StringTokenizer tokenizer = new StringTokenizer(str);
        while (tokenizer.hasMoreTokens()) {
            var word = tokenizer.nextToken();
            incKey(countMap, word, 1);
        }
        return countMap;
    }

    private static void incKey(HashMap<String, Integer> countMap, String word, int n) {
        if (countMap.containsKey(word)) {
            countMap.put(word, countMap.get(word) + n);
        } else {
            countMap.put(word, n);
        }
    }

    class CountTask implements Callable<HashMap<String, Integer>> {
        private final String fileName;
        private final long start;
        private final long end;

        public CountTask(String fileName, long start, long end) {
            this.fileName = fileName;
            this.start = start;
            this.end = end;
        }

        @Override
        public HashMap<String, Integer> call() throws IOException {
            var countMap = new HashMap<String, Integer>();
            // 允许从任意位置开始处理文件
            var channel = new RandomAccessFile(this.fileName, "rw").getChannel();

            // 调用操作系统的能力将某一区段的内容映射到用户内存中【start, end】-> memory
            // 原本的拷贝流程：Device -> kernel Space -> User Space(buffer) -> Thread
            // 这里使用channel的map方法临时将kernel Space内存原始地提供给User Space使用，省去不必要的步骤
            MappedByteBuffer mappedByteBuffer = channel.map(
                    FileChannel.MapMode.READ_ONLY,
                    this.start,
                    this.end - this.start
            );

            var str = StandardCharsets.US_ASCII.decode(mappedByteBuffer).toString();
            return countByString(str);
        }
    }

    public void run(String fileName, long chunkSize) throws ExecutionException, InterruptedException {
        var file = new File(fileName);
        var fileSize = file.length();
        long position = 0;
        var tasks = new ArrayList<Future<HashMap<String, Integer>>>();
        var start = System.currentTimeMillis();
        while (position < fileSize) {
            var next = Math.min(position + chunkSize, fileSize);
            var task = new CountTask(fileName, position, next);
            position = next;
            var future = pool.submit(task);
            tasks.add(future);
        }

        System.out.format("分割的任务个数：%d\n", tasks.size());

        var total = new HashMap<String, Integer>();
        for (var task : tasks) {
            var futureMap = task.get();
            for (var entry : futureMap.entrySet()) {
                incKey(total, entry.getKey(), entry.getValue());
            }
        }

        System.out.println("异步耗时：" + (System.currentTimeMillis() - start));
        System.out.println(total.get("abcde"));
        System.out.println(total.size());
    }

    @Test
    void asyncCountWordsTest() throws ExecutionException, InterruptedException {
        System.out.println("本机核心数：" + Runtime.getRuntime().availableProcessors());
        // 根据核心数调整chunkSize，确保任务不要太多，避免频繁地线程切换
        run("文本.txt", 1024 * 1024);
    }
}
