package singleton;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SomeTest {
    @Test
    void testSome() throws InterruptedException, ExecutionException {
        List<Callable<Integer>> callableList = IntStream.range(0, 100)
                .<Callable<Integer>>mapToObj(i -> () -> i)
                .collect(Collectors.toList());

        ExecutorService pool = Executors.newFixedThreadPool(12);

        List<Future<Integer>> futureList = pool.invokeAll(callableList);

        for (Future<Integer> future : futureList) {
            System.out.println(future.get());
        }

        pool.shutdown();
    }
}
