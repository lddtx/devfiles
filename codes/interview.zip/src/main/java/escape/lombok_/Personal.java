package escape.lombok_;

import lombok.Data;

/**
 * <h1>Java Object</h1>
 * */
@Data
public class Personal {

    private String iPhone;
    private String name;
    private String userName;
}
