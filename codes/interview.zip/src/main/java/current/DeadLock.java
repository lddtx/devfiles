package current;

import java.util.concurrent.locks.ReentrantLock;

public class DeadLock {

    static class Friend {
        private final String name;
        private final ReentrantLock lock = new ReentrantLock();

        public Friend(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        /**
         * 鞠躬
         */
        public void bow(Friend bower) {
            lock.lock();
            System.out.format("%s: %s 向我鞠躬！%n", this.name, bower.getName());
            // 这里会发生死锁，导致程序无法停止，需要调整资源获取顺序，把它放在unlock之后
            bower.release(this);
            lock.unlock();

            // 解决死锁
            // bower.release(this);
        }

        /**
         * 回鞠躬
         */
        public void release(Friend bower) {
            lock.lock();
            System.out.format("%s: %s 回了我！%n", this.name, bower.getName());
            lock.unlock();
        }
    }



    public static void main(String[] args) {
        final Friend xiaoming = new Friend("小明");
        final Friend xiaohong = new Friend("小红");

        new Thread(() -> xiaoming.bow(xiaohong)).start();
        new Thread(() -> xiaohong.bow(xiaoming)).start();

        //     抢占  尝试获取  前提先释放
        // A.bow -> A -> tryB -> releaseA
        // B.bow -> B -> tryA -> releaseB
    }
}
