package current.eating;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class DiningPhilosophersDeadlock {

    Phi[] phis = new Phi[5];
    // 叉子
    volatile int[] forks = new int[5];

    public DiningPhilosophersDeadlock() {
        for (int i = 0; i < 5; i++) {
            phis[i] = new Phi(i + 1);
            forks[i] = 0;
        }
    }


    class Phi extends Philosophy {
        public Phi(int id) {
            super(id);
        }

        @Override
        protected synchronized boolean takeLeft(int[] forks) {
            return super.takeLeft(forks);
        }

        @Override
        protected synchronized boolean takeRight(int[] forks) {
            return super.takeRight(forks);
        }

        @Override
        public void run() {
            while (true) {
                try {
                    this.thinking();
                    while (!this.takeLeft(forks)) {
                        Thread.onSpinWait();
                    }
                    System.out.println("take left");
                    // 这里的休眠就会导致死锁的概率大大增加
                    // TimeUnit.MILLISECONDS.sleep(100);
                    // 增加计数可以解决死锁问题，但会产生活锁的可能
                    int c = 0;
                    while (!this.takeRight(forks)) {
                        c++;
                        if (c > 100) {
                            this.putLeft(forks);
                            continue;
                        }
                        Thread.onSpinWait();
                    }
                    System.out.println("take right");
                    this.eating();
                    this.putLeft(forks);
                    this.putRight(forks);
                    this.finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void run() {
        var pool = Executors.newFixedThreadPool(5);
        for (int i = 0; i < 5; i++) {
            pool.submit(phis[i]);
        }
    }

    public static void main(String[] args) {
        var solver = new DiningPhilosophersDeadlock();
        solver.run();
    }
}
