package current.eating;

import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DiningPhilosophersDeadlockCondition {

    ReentrantLock lock = new ReentrantLock();
    Condition wait = lock.newCondition();

    Phi[] phis = new Phi[5];
    // 叉子
    volatile int[] forks = new int[5];

    public DiningPhilosophersDeadlockCondition() {
        for (int i = 0; i < 5; i++) {
            phis[i] = new Phi(i + 1);
            forks[i] = 0;
        }
    }


    class Phi extends Philosophy {
        public Phi(int id) {
            super(id);
        }

        @Override
        protected synchronized boolean takeLeft(int[] forks) {
            return super.takeLeft(forks);
        }

        @Override
        protected synchronized boolean takeRight(int[] forks) {
            return super.takeRight(forks);
        }

        @Override
        public void run() {
            while (true) {
                try {
                    this.thinking();
                    lock.lockInterruptibly();
                    while (!this.takeLeft(forks)) {
                        // 对CPU占用少
                        wait.await();
                    }
                    while (!this.takeRight(forks)) {
                        wait.await();
                    }

                    lock.unlock();
                    this.eating();

                    lock.lockInterruptibly();
                    this.putLeft(forks);
                    this.putRight(forks);
                    wait.signalAll();
                    lock.unlock();

                    this.finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void run() {
        var pool = Executors.newFixedThreadPool(5);
        for (int i = 0; i < 5; i++) {
            pool.submit(phis[i]);
        }
    }

    public static void main(String[] args) {
        var solver = new DiningPhilosophersDeadlockCondition();
        solver.run();
    }
}
