package current.aqs;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class SemaphoreUseDemo {
    public static void main(String[] args) {
        Semaphore semaphore = new Semaphore(2);
        Runnable runnable = () -> {
            try {
                semaphore.acquire();
                System.out.println("running... " + Thread.currentThread().getName());
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                semaphore.release();
            }
        };

        for (int i = 0; i < 10; i++) {
            new Thread(runnable).start();
        }
    }
}
