package current.aqs;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public class CountDownLatchUseDemo {
    class RPC implements Runnable {
        String url;
        CountDownLatch latch;
        public RPC(String url, CountDownLatch latch) {
            this.url = url;
            this.latch = latch;
        }

        @Override
        public void run() {
            System.out.println("请求的地址：" + this.url);
            latch.countDown();
        }
    }

    public void run() throws InterruptedException {
        ArrayList<RPC> rpcList = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(4);
        // 等待
        //CountDownLatch latch = new CountDownLatch(5);
        rpcList.add(new RPC("rpc://1", latch));
        rpcList.add(new RPC("rpc://2", latch));
        rpcList.add(new RPC("rpc://3", latch));
        rpcList.add(new RPC("rpc://4", latch));
        rpcList.forEach((x) -> new Thread(x).start());
        latch.await();

        System.out.println("合并rpc请求");
    }

    public static void main(String[] args) throws InterruptedException {
        CountDownLatchUseDemo demo = new CountDownLatchUseDemo();
        demo.run();
    }
}
