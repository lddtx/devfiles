package current.threadlocal;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadLocalDemo2 {
    private static ExecutorService pool = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    // 做成全局变量有线程安全问题
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 1000; i++) {
            int id = i;
            pool.submit(() -> {
                String birthDate = new ThreadLocalDemo2().birthDate(id);
                System.out.println(birthDate);
            });
        }

        TimeUnit.SECONDS.sleep(1);
    }

    public String birthDate(int userId) {
        Date birthDate = birthDateFromDB(userId);
        return sdf.format(birthDate);
    }

    public static Date birthDateFromDB(int userId) {
        return new Date();
    }
}
