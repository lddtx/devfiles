package current.threadlocal;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadLocalDemo {
    private static ExecutorService pool = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 1000; i++) {
            int id = i;
            pool.submit(() -> {
                String birthDate = new ThreadLocalDemo().birthDate(id);
                System.out.println(birthDate);
            });
        }

        TimeUnit.SECONDS.sleep(1);
    }

    public String birthDate(int userId) {
        Date birthDate = birthDateFromDB(userId);
        // 提交到线程池到1000个任务在这里创建SimpleDateFormat多达1000次，浪费内存不合理
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(birthDate);
    }

    public static Date birthDateFromDB(int userId) {
        return new Date();
    }
}
