package current;

import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockForLock {

    private static ReentrantLock lock = new ReentrantLock();

    public static void main(String[] args) {
        // 阻塞加锁
        lock.lock();

        // 非阻塞加锁
        lock.tryLock();

        // 自旋加锁
        while (!lock.tryLock()) {

        }
    }
}
