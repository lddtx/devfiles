package current.queues;

import java.util.concurrent.*;

public class BlockingQueueDemo {
    public static void main(String[] args) {
        BlockingQueue<Integer> queue;
//        queue = new ArrayBlockingQueue<>(10);
//        queue = new LinkedBlockingQueue<>();
//        queue = new LinkedBlockingDeque<>();
//        queue = new PriorityBlockingQueue<>();
        queue = new LinkedTransferQueue<>();
//        queue = new SynchronousQueue<>();
//        queue = new DelayQueue<>();
        // 生产者
        for (int i = 0; i < 100; i++) {
            new Thread(() -> {
                queue.offer((int) (Math.random() * 1000));
            }).start();
        }

        // 消费者
        for (int i = 0; i < 10; i++) {
            new Thread(() -> {
                while (true) {
                    Integer x = queue.poll();
                    System.out.println("收到: " + x);
                    try {
                        TimeUnit.MILLISECONDS.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}
