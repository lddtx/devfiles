package current.queues;

import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class SynchronousQueueDemo {

    static class Scheduler {
        // 可以使用公平new SynchronousQueue<>(true)、非公平结构new SynchronousQueue<>(false)
        SynchronousQueue<Runnable> tasks = new SynchronousQueue<>();

        static AtomicInteger idCount = new AtomicInteger(0);

        class Worker implements Runnable {
            int id;
            public Worker() {
                this.id = idCount.getAndIncrement();
            }

            @Override
            public void run() {
                while (true) {
                    Runnable runnable = null;
                    try {
                        runnable = tasks.take();
                        runnable.run();
                        System.out.format("work done by id = %d\n", id);
                        TimeUnit.MILLISECONDS.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        public Scheduler(int workers) {
            for (int i = 0; i < workers; i++) {
                new Thread(new Worker()).start();
            }
        }

        public void submit(Runnable r) {
            if (!tasks.offer(r)) {
                Thread.onSpinWait();
                new Thread(new Worker()).start();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Scheduler scheduler = new Scheduler(10);

        for (int i = 0; i < 1000; i++) {
            int localI = i;
            TimeUnit.MILLISECONDS.sleep(1);
            scheduler.submit(() -> {
                try {
                    TimeUnit.MILLISECONDS.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        }
    }
}
