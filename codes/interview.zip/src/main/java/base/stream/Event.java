package base.stream;

import java.util.stream.Stream;

/**
 * Event相当于上下文
 * monad概念
 * 自函子map
 * 幺半群
 * 群中的对象和自函子一起使用达到某种效果
 */
public class Event<T> {
    T data;
    public Event(T data) {
        this.data = data;
    }

    static class EventData {
        Integer id;
        String msg;

        public EventData(Integer id, String msg) {
            this.id = id;
            this.msg = msg;
        }

        @Override
        public String toString() {
            return "EventData{" +
                    "id=" + id +
                    ", msg='" + msg + '\'' +
                    '}';
        }
    }

    static class Transforms {
        static EventData transform(Integer id) {
            switch (id) {
                case 0:
                    return new EventData(id, "Start");
                case 1:
                    return new EventData(id, "Running");
                case 2:
                    return new EventData(id, "Done");
                case 3:
                    return new EventData(id, "Fail");
                default:
                    return new EventData(id, "Error");
            }
        }
    }

    @FunctionalInterface
    interface FN<A, B> {
        B apply(A a);
    }


    /**
     * @param f 函数，入参为T
     * @param <B> f的返回是根据传入的函数推导出来的，这里用B
     * @return 返回也是不确定的，这里用？
     */
    <B> Event<?> map(FN<T, B> f) {
        return new Event<>(f.apply(this.data));
    }

    public static void main(String[] args) {
        Stream<Event<Integer>> s = Stream.of(
                new Event<>(0),
                new Event<>(1),
                new Event<>(2),
                new Event<>(3),
                new Event<>(4)
        );

        // 将整数类型的event转换成了eventData类型的event
        s.map(event -> event.map(Transforms::transform))
                .forEach(eventData -> System.out.println(eventData.data));

    }
}
