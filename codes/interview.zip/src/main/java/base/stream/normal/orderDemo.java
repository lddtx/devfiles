package base.stream.normal;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;
import static org.junit.jupiter.api.Assertions.*;

public class orderDemo {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("this", "is", "a", "stream", "of", "string");
        Set<String> wordSet1 = new HashSet<>(words);
        Set<String> wordSet2 = new HashSet<>(wordSet1);

        // 添加足够多的元素来强制进行再散列操作-forEachOrdered严格按照顺序取数据
        IntStream.rangeClosed(0, 50).forEachOrdered(i -> wordSet2.add(String.valueOf(i)));

        // 删除足够多的元素来强制进行再散列操作
        wordSet2.retainAll(words);
        assertEquals(wordSet1, wordSet2);
        // rehashing后的顺序已经不一样了
        System.out.println("before: " + wordSet1);
        System.out.println("after: " + wordSet2);

    }
}
