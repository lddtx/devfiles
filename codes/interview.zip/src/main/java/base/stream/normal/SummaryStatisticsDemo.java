package base.stream.normal;

import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class SummaryStatisticsDemo {
    public static void main(String[] args) {
        DoubleSummaryStatistics statistics = DoubleStream.generate(Math::random)
                .limit(1_000_000)
                .summaryStatistics();

        System.out.println(statistics);
        System.out.println("count: " + statistics.getCount());
        System.out.println("min: " + statistics.getMin());
        System.out.println("max: " + statistics.getMax());
        System.out.println("sum: " + statistics.getSum());
        System.out.println("ave: " + statistics.getAverage());

        List<Team> teams = Stream.of(new Team(1, 245269675.00),
                        new Team(2, 445269544.00),
                        new Team(3, 9045269535.00))
                .collect(Collectors.toList());

        DoubleSummaryStatistics summaryStatistics = teams.stream()
                .mapToDouble(Team::getSalary)
                .collect(DoubleSummaryStatistics::new,
                        DoubleSummaryStatistics::accept,
                        DoubleSummaryStatistics::combine);

        System.out.println(summaryStatistics);

        DoubleSummaryStatistics doubleSummaryStatistics = teams.stream()
                .collect(Collectors.summarizingDouble(Team::getSalary));
        System.out.println(doubleSummaryStatistics);

    }
}
