package base.stream.normal;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReduceDemo {
    public static void main(String[] args) {
        var books = Stream.of(new Book(1, "Java多线程实战"),
                new Book(2, "Mysql进阶"),
                new Book(3, "Docker进阶"),
                new Book(4, "Java核心"))
                .collect(Collectors.toList());

        var bookMaps = books.stream().reduce(new HashMap<Integer, Book>(), (map, book) -> {
                map.put(book.getId(), book);
                return map;
            }, (map1, map2) -> { map1.putAll(map2); return map1;});

        bookMaps.forEach((k, v) ->
            System.out.println(k + ": " + v)
        );

        BigDecimal total = Stream.iterate(BigDecimal.ONE, n -> n.add(BigDecimal.ONE))
                .limit(10)
                .reduce(BigDecimal.ZERO, (acc, value) -> acc.add(value));

        System.out.println("BigDecimal total: " + total);
    }
}
