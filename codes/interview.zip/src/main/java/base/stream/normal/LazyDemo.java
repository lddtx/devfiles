package base.stream.normal;

import java.util.stream.IntStream;

public class LazyDemo {
    public static void main(String[] args) {
        IntStream.rangeClosed(100, 200)
                .map(LazyDemo::multiByTwo)
                .filter(LazyDemo::divByThree)
                .findFirst();
    }

    public static int multiByTwo(int n) {
        System.out.printf("Inside multiByTwo with arg %d%n", n);
        return n * 2;
    }

    public static boolean divByThree(int n) {
        System.out.printf("Inside divByThree with arg %d%n", n);
        return n % 3 == 0;
    }
}
