package base.stream.normal;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Team {
    private int id;
    private double salary;
}
