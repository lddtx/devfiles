package base.stream;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class CountLongWords {
    public static void main(String[] args) throws IOException {
        // Java8
        var content = new String(Files.readAllBytes(Paths.get("src/main/java/base/stream/CountLongWords.java")), StandardCharsets.UTF_8);
        // Java11
        // var content = Files.readString(Paths.get("文本.txt"));


        List<String> words = List.of(content.split("\\PL+"));

        words.stream().filter(w -> w.length() > 12).distinct().forEach(System.out::println);
        long count = 0;
        count = words.stream().filter(w -> w.length() > 12).distinct().count();
        System.out.println(count);
    }
}
