package base.system;

public class GetAllProperties {
    public static void main(String[] args) {
        var properties = System.getProperties();
        var keySet = properties.keySet();
        keySet.forEach(ks -> System.out.println("System Property: {" + ks.toString() + " => "
                + System.getProperty(ks.toString()) + "}"));
    }
}
