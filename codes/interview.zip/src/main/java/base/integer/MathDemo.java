package base.integer;

public class MathDemo {
    public static void main(String[] args) {
        System.out.println(Math.abs(2));
        System.out.println(Math.abs(-2));

        double cosp3 = Math.cos(0.3);
        double sinp3 = Math.sin(0.3);
        System.out.println((cosp3 * cosp3 + sinp3 * sinp3)); // 始终为1.0

        System.out.println(Math.max(0.3, 0.7));
        System.out.println(Math.max(0.3, -0.3));
        System.out.println(Math.max(-0.3, -0.7));

        System.out.println(Math.min(0.3, 0.7));
        System.out.println(Math.min(0.3, -0.3));
        System.out.println(Math.min(-0.3, -0.7));

        System.out.println(Math.floor(1.3));
        System.out.println(Math.ceil(1.3));
        System.out.println(Math.floor(7.5));
        System.out.println(Math.ceil(7.5));

        System.out.println(Math.round(1.3)); // 返回值为long类型
        System.out.println(Math.round(7.5)); // 返回值为long类型

        System.out.println(Math.pow(2.0, 10.0));
        System.out.println(Math.exp(1));
        System.out.println(Math.exp(2));
        System.out.println(Math.log(2.718281828459045));
        System.out.println(Math.log10(100_000));
        System.out.println(Math.log10(Integer.MAX_VALUE));

        System.out.println(Math.random());
        System.out.println("Let's toss a coin: ");
        if (Math.random() > 0.5) {
            System.out.println("It's heads");
        } else {
            System.out.println("It's tails");
        }
    }
}
