package base.integer;

import java.math.BigDecimal;
import java.math.BigInteger;

public class IntegerDemo {
    public static void main(String[] args) {
        // byte 类型的数字占 8 位，因此能表示 256 个不同的数字（即 128 个正数和 128 个负数）。
        // 0b0000_0000 表示的是零（在 Java 中可以使用 0b<binary digits> 这样的句法表示二进制数）
        byte b = 0b0000_0001;
        System.out.println(b);//1

        b = 0b0000_0010;
        System.out.println(b); // 2

        b = 0b0000_0011;
        System.out.println(b); // 3

        // ...

        b = 0b0111_1111;
        System.out.println(b); // 127

        System.out.println("###############");
        // 如果位组合的高位是 1，表示的就是负数。
        // 这种表示方式叫二进制补码，带符号的整数最常使用这种表示方式
        b = (byte) 0b1111_1111; // -1
        System.out.println(b);
        b++;
        System.out.println(b); // 0

        b = (byte) 0b1111_1110; // -2
        System.out.println(b);
        b++;
        System.out.println(b); // -1

        b = (byte) 0b1000_0000;
        System.out.println(b); // -128

        // Java 的其他整数类型（short、int 和 long）和 byte 的行为十分相似，只不过位数更多.
        // 但是 char 类型有所不同，因为它表示的是 Unicode 字符，不过可以使用某种方式表示成无符号的 16 位数字类型。Java 程序员一般不会把 char 当成整数类型。


        // 规范浮点计算的标准是 IEEE-754，Java 就是基于这个标准实现的浮点数。
        // 按照这个标准，表示标准精度的浮点数要使用 24 个二进制数，表示双精度浮点数要使用 53 个二进制数。
        double d = 0.3;
        System.out.println(d);

        double d2 = 0.2;
        // 应该是-0.1，但打印出来的是-0.09999999999999998
        System.out.println(d2 - d);


        System.out.println("#############");
        // 使用BigDecimal
        double d3 = 0.3;
        System.out.println(d3);

        // BigDecimal 对象和 Java 基本类型之间相互转换时还是会遇到一些边缘情况
        BigDecimal bd = new BigDecimal(d3);
        System.out.println(bd);

        bd = new BigDecimal("0.3");
        System.out.println(bd);

        // BigDecimal 无法精确表示 1/3，所以调用 divide() 方法时会抛出 ArithmeticException 异常
        bd = new BigDecimal(BigInteger.ONE);
        bd.divide(new BigDecimal(3.0));
        System.out.println(bd); // 应该是1/3
    }
}
