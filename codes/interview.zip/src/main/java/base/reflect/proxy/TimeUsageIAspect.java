package base.reflect.proxy;

public class TimeUsageIAspect implements IAspect {

    long start;

    @Override
    public void before() {
        start = System.currentTimeMillis();
    }

    @Override
    public void after() {
        var usage = System.currentTimeMillis() - this.start;
        System.out.println("耗时：" + usage);
    }
}
