package base.reflect.proxy;

public interface IOrder {
    void pay() throws InterruptedException;
    void show();
}
