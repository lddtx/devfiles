package base.reflect.annotation;

public interface IOrder {
    void pay() throws InterruptedException;
    void show();
}
