package base.reflect.annotation;

/**
 * 保持接口的单一声明功能，而不是加各种静态方法
 */
public interface IAspect {
    void before();
    void after();
}
