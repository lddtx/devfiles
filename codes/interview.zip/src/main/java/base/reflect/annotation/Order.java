package base.reflect.annotation;

import java.util.concurrent.TimeUnit;

@Aspect(type = TimeUsageIAspect.class)
public class Order implements IOrder {
    int state = 0;

    @Override
    public void pay() throws InterruptedException {
        TimeUnit.MILLISECONDS.sleep(50);
        this.state = 1;
    }

    @Override
    public void show() {
        System.out.println("订单状态：" + this.state);
    }
}
