package base.reflect;

public class MyClass {
    @MyAnnotation(ids = {"4567", "7890"})
    public void getMyId() {
    }
}
