package base.time;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class BirthdayDiary {
    private Map<String, LocalDate> birthdays;

    public BirthdayDiary() {
        this.birthdays = new HashMap<>();
    }

    public LocalDate addBirthday(String name, int day, int mouth, int year) {
        LocalDate birthday = LocalDate.of(year, mouth, day);
        birthdays.put(name, birthday);
        return birthday;
    }

    public LocalDate getBirthdayFor(String name) {
        return birthdays.get(name);
    }

    public int getAgeInYear(String name, int year) {
        Period period = Period.between(birthdays.get(name), birthdays.get(name).withYear(year));
        return period.getYears();
    }

    public Set<String> getFriendsOfAgeIn(int age, int year) {
        return birthdays.keySet().stream()
                .filter(p -> getAgeInYear(p, year) == age)
                .collect(Collectors.toSet());
    }

    public int getDaysUntilBirthday(String name) {
        Period period = Period.between(LocalDate.now(), birthdays.get(name));
        return period.getDays();
    }

    public Set<String> getBirthdaysIn(Month month) {
        return birthdays.entrySet().stream()
                .filter(e -> e.getValue().getMonth() == month)
                .map(e -> e.getKey())
                .collect(Collectors.toSet());
    }

    public Set<String> getBirthdaysInNextMonth() {
        return getBirthdaysIn(LocalDate.now().getMonth());
    }

    public int getTotalAgeNow() {
        return birthdays.keySet().stream()
                .mapToInt(k -> getAgeInYear(k, LocalDate.now().getYear()))
                .sum();
    }

    public static void main(String[] args) {
        BirthdayDiary diary = new BirthdayDiary();
        diary.addBirthday("zhou", 18, 8, 1993);
        // 计算年纪
        System.out.println(diary.getAgeInYear("zhou", 2021));
        System.out.println(diary.getTotalAgeNow());

        // 查找年纪
        System.out.println(diary.getFriendsOfAgeIn(28, 2021));

        // 生日还有多少天
        System.out.println(diary.getDaysUntilBirthday("zhou"));
    }
}
