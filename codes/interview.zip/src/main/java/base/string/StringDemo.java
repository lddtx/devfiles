package base.string;

/**
 * Java 的字符串是不可变的。也就是说，选定组成字符串的字符并创建 String 对象后，
 * 字符串的内容就不能改变了。这是 Java 语言的一个重要规则
 */
public class StringDemo {
    public static void main(String[] args) {
        String s1 = "AB";
        String s2 = "CD";
        String s3 = s1;
        System.out.println(s1 == s3);

        s3 = s1 + s2;
        System.out.println(s1 == s3);
        System.out.println(s1);
        System.out.println(s3);
    }
}
