package base.sort;

import java.util.List;

/**
 * Immutable表示可以不可变更的，这里传入什么对象
 * 就返回什么对象
 */
public interface IImmutableSorter {
    List<Integer> sort(List<Integer> A);
}
