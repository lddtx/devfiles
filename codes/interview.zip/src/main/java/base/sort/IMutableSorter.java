package base.sort;

/**
 * Mutable表示可以变更的，这里传入数组对象
 * 没有返回，表示数组是可以改变的
 */
public interface IMutableSorter {
    void sort(int[] A);
}
