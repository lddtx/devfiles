package base.sort.normal;

import base.sort.IMutableSorter;
import base.sort.Swapper;

public class BobbleSort implements IMutableSorter {
    @Override
    public void sort(int[] A) {
        for(int i = A.length - 1; i >=0; i--) {
            // 找到0-i间的最大元素放到A[i]
            bubble(A, 0, i+1);
        }
    }

    /**
     * 相对其它排序，这里写比较多，不停地交换位置
     * 而选择排序相对较少地交换(写数据)
     * CPU缓存对于读是有利的，而写数据是不能读缓存的
     * 所以写数据多的情况下，速度是很慢的
     */
    private void bubble(int[] A, int i, int j) {
        for(int k = 0; k < j - 1; k++) {
            if(A[k] > A[k+1]) {
                Swapper.swap(A, k, k+1);
            }
        }
    }
}
