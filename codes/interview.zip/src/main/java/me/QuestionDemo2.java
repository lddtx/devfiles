package me;

import java.util.Scanner;

/**
 * 两个字符串的不同字符统计
 */
public class QuestionDemo2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int len1;
        int len2;
        String s1;
        String s2;
        while (true) {
            System.out.println("请输入len1长度: ");
            len1 = Integer.parseInt(scanner.nextLine());
            System.out.println("请输入s1: ");
            s1 = scanner.nextLine();


            System.out.println("请输入len2长度: ");
            len2 = Integer.parseInt(scanner.nextLine());
            System.out.println("请输入s2: ");
            s2 = scanner.nextLine();
            System.out.println("输入结束!");
            break;
        }

        char[] c1 = s1.toCharArray();
        char[] c2 = s2.toCharArray();
        int count = 0;
        if (len1 >= len2) {
            for (int i = len2 - 1; i >=0 ; i--) {
                if (c1[i] != c2[i]) {
                    count++;
                }
            }
        } else {
            for (int i = len1 - 1; i >=0 ; i--) {
                if (c1[i] != c2[i]) {
                    count++;
                }
            }
        }

        System.out.println("不同字符统计：" + count);
    }
}
