package me;

import java.util.stream.IntStream;

/**
 * 打印满足三位数的百位数字+个位数字=十位数字的所有数字
 */
public class QuestionDemo {
    public static void main(String[] args) {
        IntStream.rangeClosed(100, 999)
                .forEachOrdered(i -> {
                    if (i/100 + i%10 == (i%100)/10) {
                        System.out.println(i);
                    }
                });

        System.out.println("**********");
        for (int i = 100; i < 1000; i++) {
            if (i/100 + i%10 == (i%100)/10) {
                System.out.println(i);
            }
        }
    }
}
