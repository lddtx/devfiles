<h3 align = "center">
    <img src = "https://gitee.com/zhouguangping/image/raw/master/markdown/jonny-caspari-TQGpLw48VsU-unsplash.jpg"/>
</h3>

---

#### 正则表达式
Java 使用 Pattern 类（在 java.util.regex 包中）表示正则表达式。不过，这个类不能直接实例化，只能使用静态工厂方法 compile() 创建实例。然后，再从模式上创建某个输入字符串的 Matcher 对象，用于匹配输入字符串。

**正则表达式元字符**

<table>
    <tr>
        <td>元字符</td>
        <td>意义</td>
        <td>备注</td>
    </tr>
    <tr>
        <td>？</td>
        <td>可选字符-前一个字符是可选的，出现零次或一次</td>
        <td></td>
    </tr>
    <tr>
        <td>*</td>
        <td>前一个字符出现零次或多次</td>
        <td></td>
    </tr>
    <tr>
        <td>+</td>
        <td>前一个字符出现一次或多次</td>
        <td></td>
    </tr>
    <tr>
        <td>{M,N}</td>
        <td>前一个字符出现M到N次</td>
        <td></td>
    </tr>
    <tr>
        <td>\d</td>
        <td>一个数字</td>
        <td></td>
    </tr>
    <tr>
        <td>\D</td>
        <td>一个不是数字的字符</td>
        <td></td>
    </tr>
    <tr>
        <td>\w</td>
        <td>一个组成单词的字符</td>
        <td>数字、字母和_</td>
    </tr>
    <tr>
        <td>\W</td>
        <td>一个不能组成单词的字符</td>
        <td></td>
    </tr>
    <tr>
        <td>\s</td>
        <td>一个空白字符</td>
        <td></td>
    </tr>
    <tr>
        <td>\S</td>
        <td>一个不是空白字符</td>
        <td></td>
    </tr>
    <tr>
        <td>\n</td>
        <td>换行符</td>
        <td></td>
    </tr>
    <tr>
        <td>\t</td>
        <td>制表符</td>
        <td></td>
    </tr>
    <tr>
        <td>.</td>
        <td>任意一个字符</td>
        <td>在Java中不包含换行符</td>
    </tr>
    <tr>
        <td>[]</td>
        <td>方括号中任意一个字符</td>
        <td>叫作字符组</td>
    </tr>
    <tr>
        <td>[^]</td>
        <td>不在方括号中的任意一个字符</td>
        <td>叫作排除字符组</td>
    </tr>
    <tr>
        <td>()</td>
        <td>构成一组模式元素</td>
        <td>叫作组(或捕获组)</td>
    </tr>
    <tr>
        <td>|</td>
        <td>定义可选值</td>
        <td>实现逻辑或</td>
    </tr>
    <tr>
        <td>^</td>
        <td>字符串的开头</td>
        <td></td>
    </tr>
    <tr>
        <td>$</td>
        <td>字符串的结尾</td>
        <td></td>
    </tr>
</table>


```java
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class PatternDemo {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("honou?r");

        String caesarUK = "For Brutus is an honourable man";
        Matcher mUK = pattern.matcher(caesarUK);

        String caesarUS = "For Brutus is an honorable man";
        Matcher mUS = pattern.matcher(caesarUS);

        System.out.println("Matches UK spelling? " + mUK.find());
        System.out.println("Matches US spelling? " + mUS.find());


        // 注意，必须使用\\，因为我们需要的是字面量\，而Java使用单个\转义字符
        String pStr = "\\d"; // 一个数字
        String text = "Apollo 13";
        Pattern p = Pattern.compile(pStr);
        Matcher m = p.matcher(text);
        System.out.print(pStr + " matches " + text + "? " + m.find());
        System.out.println(" ; match: " + m.group());

        pStr = "[a..zA..Z]"; // 任意一个字母
        p = Pattern.compile(pStr);
        m = p.matcher(text);
        System.out.print(pStr + " matches " + text + "? " + m.find());
        System.out.println(" ; match: " + m.group());

        // 任意个字母，但字母只能在a到j之间，大小写不限
        pStr = "([a..jA..J]*)";
        p = Pattern.compile(pStr);
        m = p.matcher(text);
        System.out.print(pStr + " matches " + text + "? " + m.find());
        System.out.println(" ; match: " + m.group());

        text = "abacab";
        pStr = "a....b"; // a和b之间有四个字符
        p = Pattern.compile(pStr);
        m = p.matcher(text);
        System.out.print(pStr + " matches " + text + "? " + m.find());
        System.out.println(" ; match: " + m.group());

        // Java8的asPredicate方法
        String pStr1 = "\\d"; // 一个数字
        Pattern pattern1 = Pattern.compile(pStr1);
        List<String> ls = Arrays.asList("Cat", "Dog", "Ice-9", "99 Luftballoons");
        List<String> containDigits = ls.stream()
                .filter(pattern1.asPredicate())
                .collect(Collectors.toList());
        System.out.println(containDigits);
    }
}
```

```
Matches UK spelling? true
Matches US spelling? true
\d matches Apollo 13? true ; match: 1
[a..zA..Z] matches Apollo 13? true ; match: A
([a..jA..J]*) matches Apollo 13? true ; match: A
a....b matches abacab? true ; match: abacab
[Ice-9, 99 Luftballoons]
```

#### 整数
byte 类型的数字占 8 位，因此能表示 256 个不同的数字（即 128 个正数和 128 个负数）。
0b0000_0000 表示的是零（在 Java 中可以使用 0b<binary digits> 这样的句法表示二进制数）
Java 的其他整数类型（short、int 和 long）和 byte 的行为十分相似，只不过位数更多.
但是 char 类型有所不同，因为它表示的是 Unicode 字符，
不过可以使用某种方式表示成无符号的 16 位数字类型。Java 程序员一般不会把 char 当成整数类型。
规范浮点计算的标准是 IEEE-754，Java 就是基于这个标准实现的浮点数。
按照这个标准，表示标准精度的浮点数要使用 24 个二进制数，表示双精度浮点数要使用 53 个二进制数。
程序员使用浮点数时，舍入误差始终是个让人头疼的问题。为了解决这个问题，Java 提供了 java.math.BigDecimal 类，
这个类以小数形式实现任意精度的计算。使用这个类可以解决有限个二进制位无法表示 0.1 的问题

```java
import java.math.BigDecimal;
import java.math.BigInteger;

public class IntegerDemo {
    public static void main(String[] args) {
        // byte 类型的数字占 8 位，因此能表示 256 个不同的数字（即 128 个正数和 128 个负数）。
        // 0b0000_0000 表示的是零（在 Java 中可以使用 0b<binary digits> 这样的句法表示二进制数）
        byte b = 0b0000_0001;
        System.out.println(b);//1

        b = 0b0000_0010;
        System.out.println(b); // 2

        b = 0b0000_0011;
        System.out.println(b); // 3

        // ...

        b = 0b0111_1111;
        System.out.println(b); // 127

        System.out.println("###############");
        // 如果位组合的高位是 1，表示的就是负数。
        // 这种表示方式叫二进制补码，带符号的整数最常使用这种表示方式
        b = (byte) 0b1111_1111; // -1
        System.out.println(b);
        b++;
        System.out.println(b); // 0

        b = (byte) 0b1111_1110; // -2
        System.out.println(b);
        b++;
        System.out.println(b); // -1

        b = (byte) 0b1000_0000;
        System.out.println(b); // -128

        // Java 的其他整数类型（short、int 和 long）和 byte 的行为十分相似，只不过位数更多.
        // 但是 char 类型有所不同，因为它表示的是 Unicode 字符，不过可以使用某种方式表示成无符号的 16 位数字类型。Java 程序员一般不会把 char 当成整数类型。


        // 规范浮点计算的标准是 IEEE-754，Java 就是基于这个标准实现的浮点数。
        // 按照这个标准，表示标准精度的浮点数要使用 24 个二进制数，表示双精度浮点数要使用 53 个二进制数。
        double d = 0.3;
        System.out.println(d);

        double d2 = 0.2;
        // 应该是-0.1，但打印出来的是-0.09999999999999998
        System.out.println(d2 - d);


        System.out.println("#############");
        // 使用BigDecimal
        double d3 = 0.3;
        System.out.println(d3);

        // BigDecimal 对象和 Java 基本类型之间相互转换时还是会遇到一些边缘情况
        BigDecimal bd = new BigDecimal(d3);
        System.out.println(bd);

        bd = new BigDecimal("0.3");
        System.out.println(bd);

        // BigDecimal 无法精确表示 1/3，所以调用 divide() 方法时会抛出 ArithmeticException 异常
        bd = new BigDecimal(BigInteger.ONE);
        bd.divide(new BigDecimal(3.0));
        System.out.println(bd); // 应该是1/3
    }
}
```

```
1
2
3
127
###############
-1
0
-2
-1
-128
0.3
-0.09999999999999998
#############
0.3
0.299999999999999988897769753748434595763683319091796875
0.3
Exception in thread "main" java.lang.ArithmeticException: Non-terminating decimal expansion; no exact representable decimal result.
	at java.base/java.math.BigDecimal.divide(BigDecimal.java:1722)
	at base.integer.IntegerDemo.main(IntegerDemo.java:68)
```

#### Java的数学函数标准库 
* abs()

返回指定数的绝对值。不同的基本类型都有对应的重载方法。

* 三角函数

计算正弦、余弦和正切等的基本函数。Java 还提供了双曲线版本和反函数（例如反正弦）。

* max()和min()

这两个是重载的函数，分别返回两个参数（属于同一种数字类型）中较大的数和较小的数。

* floor()

返回比指定参数（double 类型）小的最大整数。ceil() 方法返回比指定参数大的最小整数。

* pow()、exp()和log()

pow() 方法以第一个参数为底数，第二个参数为指数，计算次方；exp() 方法做指数运算；log() 方法做对数运算。log10() 方法计算对数时以 10 为底数，而不是自然常数。
 
```java
public class MathDemo {
    public static void main(String[] args) {
        System.out.println(Math.abs(2));
        System.out.println(Math.abs(-2));

        double cosp3 = Math.cos(0.3);
        double sinp3 = Math.sin(0.3);
        System.out.println((cosp3 * cosp3 + sinp3 * sinp3)); // 始终为1.0

        System.out.println(Math.max(0.3, 0.7));
        System.out.println(Math.max(0.3, -0.3));
        System.out.println(Math.max(-0.3, -0.7));

        System.out.println(Math.min(0.3, 0.7));
        System.out.println(Math.min(0.3, -0.3));
        System.out.println(Math.min(-0.3, -0.7));

        System.out.println(Math.floor(1.3));
        System.out.println(Math.ceil(1.3));
        System.out.println(Math.floor(7.5));
        System.out.println(Math.ceil(7.5));

        System.out.println(Math.round(1.3)); // 返回值为long类型
        System.out.println(Math.round(7.5)); // 返回值为long类型

        System.out.println(Math.pow(2.0, 10.0));
        System.out.println(Math.exp(1));
        System.out.println(Math.exp(2));
        System.out.println(Math.log(2.718281828459045));
        System.out.println(Math.log10(100_000));
        System.out.println(Math.log10(Integer.MAX_VALUE));

        System.out.println(Math.random());
        System.out.println("Let's toss a coin: ");
        if (Math.random() > 0.5) {
            System.out.println("It's heads");
        } else {
            System.out.println("It's tails");
        }
    }
}
```

```
2
2
1.0
0.7
0.3
-0.3
0.3
-0.3
-0.7
1.0
2.0
7.0
8.0
1
8
1024.0
2.718281828459045
7.38905609893065
1.0
5.0
9.331929865381182
0.680932337016637
Let's toss a coin: 
It's tails
```

#### 日期和时间
Java 8 引入了一个新包 java.time，包含了多数开发者都会用到的核心类。这个包分为四个子包。

* java.time.chrono
开发者使用的历法不符合 ISO 标准时，需要与之交互的其他纪年法。例如日本历法。 

* java.time.format
这个包中的 DateTimeFormatter 类用于把日期和时间对象转换成字符串，以及把字符串解析成日期和时间对象。

* java.time.temporal
包含日期和时间核心类所需的接口，还抽象了一些日期方面的高级操作（例如查询和调节器）。

* java.time.zone
底层时区规则使用的类；多数开发者都用不到这个包。

Java 8 使用一个 Instant 对象表示一个时间点，而且做了下述关键假设：

* 表示的秒数不能超出 long 类型的取值范围；

* 表示的时间不能比纳秒还精细。

因此，能表示的时间受到当前计算机系统的能力所限制。不过，还有一个基本概念需要介绍。
Instant 对象是时空中的单一事件。可是，程序员经常要处理的却是两个事件之间的时间间隔，
所以 Java 8 还引入了 java.time.Duration 类。这个类会忽略可能出现的日历效应（例如夏令时）。
关键是要知道，不同的地方适合使用不同的抽象方式。例如，有些商业应用主要处理的是 LocalDate 对象，
此时需要的时间粒度是一个工作日。而有些应用需要亚秒级甚至是毫秒级精度。
开发者要了解所需的业务逻辑，在应用中使用合适的表示方式。

