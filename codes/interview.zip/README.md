### 📚纪要
🏖使用浏览器打开新的无痕窗口，在不登录的情况下查询用户名来找到项目

⚙修改查询用户名关键字：设置-个人资料-个人空间地址

🍬修改后记得更新本地仓库的远程地址

🍺修改仓库对应的远程仓库地址：
```bash
 git remote set-url origin 仓库地址
```

🎁查看当前仓库对应的远程仓库地址
```bash
 git remote -v 
```
这条命令能显示你当前仓库中已经添加了的仓库名和对应的仓库地址，通常来讲，会有两条一模一样的记录，分别是fetch和push，其中fetch是用来从远程同步 push是用来推送到远程

🗑从git中移除某个文件
```bash
 git rm 文件名 --cached
```

比较实用的面试资源库

🤔<a href="https://github.com/resumejob/awesome-resume">海外兔</a>

🤩<a href="https://github.com/yifeikong/reverse-interview-zh">反向面试</a>