### Mysql相关
#### 索引相关
[B+Tree数据结构演示](https://www.cs.usfca.edu/~galles/visualization/BPlusTree.html)
<h3 align = "center">
    <img src = "https://gitee.com/zhouguangping/image/raw/master/markdown/20210823162508.png"/>
</h3>

页数据引出B+Tree

<h3 align = "center">
    <img src = "https://gitee.com/zhouguangping/image/raw/master/markdown/20210823161925.png"/>
</h3>

主键索引
<h3 align = "center">
    <img src = "https://gitee.com/zhouguangping/image/raw/master/markdown/20210823160957.png"/>
</h3>

联合索引
<h3 align = "center">
    <img src = "https://gitee.com/zhouguangping/image/raw/master/markdown/20210823161248.png"/>
</h3>

测试数据
```sql
-- 测试数据表
create table t1 (
    a int primary key,
    b int,
    c int,
    d int,
    e varchar(20)
) engine=InnoDB;

show index from t1;

insert into t1 values (1, 1, 1, 1, 'a');
insert into t1 values (2, 2, 2, 2, 'b');
insert into t1 values (3, 3, 2, 2, 'c');
insert into t1 values (4, 3, 1, 1, 'd');
insert into t1 values (5, 2, 3, 5, 'e');
insert into t1 values (6, 6, 4, 4, 'f');
insert into t1 values (7, 4, 5, 5, 'g');
insert into t1 values (8, 8, 8, 8, 'h');

-- 插入无序，查询却进行了排序(主键索引的效果)
select * from t1;

-- 插入会根据主键排序，innodb一页数据的大小16kb
show global status like 'Innodb_page_size'; -- 16384
select 16384/1024; -- 16kb
select * from t1 where a = 7; -- 七次的磁盘IO -> 使用页page -> 一次查询16kb数据放在内存中，不需要七次的IO


-- 走索引
explain select * from t1 where a = 5;
-- 先走a = 7，再找下一节点数据
explain select * from t1 where a > 7;

-- 全表扫描
explain select * from t1 where b = 7;

-- 联合索引
create index idx_t1_bcd on t1(b, c, d); -- B+Tree

explain select * from t1 where d = 1; -- 无法走索引
-- 最左前缀原则 - 无法确定索引走左子树还是右子树 *11 比较是按顺序来的 b->c->d
explain select * from t1 where b = 1; -- 可以走索引 1**
explain select * from t1 where b = 1 and d = 1; -- 可以走索引 1*1
explain select * from t1 where b = 1 and c = 1; -- 可以走索引 11*
explain select * from t1 where c = 1 and d = 1; -- 没有走索引 *11
explain select * from t1 where b = 1 and c = 1 and d = 1; -- 完全命中索引 111
-- select * 的其他数据会进行回表 索引 + 7次回表 > 全表扫描
explain select * from t1 where b > 1; -- 没有走索引 possible_keys有提示走索引，但是全表扫描更快，引擎选择了更快的
-- select * 的其他数据会进行回表 索引 + 1次回表 < 全表扫描
explain select * from t1 where b > 6; -- 可以走索引

-- bcd索引是不完整的字段索引，在select * 的查询下要回表，而单独的字段则不需要回表
explain select b,c,d from t1 where b > 1; -- 可以走索引
explain select b,c from t1 where b > 1; -- 可以走索引
explain select b from t1 where b > 1; -- 可以走索引

-- bcd索引有a主键索引，其作用就是进行回表，查询所有字段
explain select b,c,d,a from t1 where b > 1; -- 可以走索引

explain select * from t1 where b = 1; -- 可以走索引

-- 隐式类型转换
create index idx_t1_e on t1(e);
explain select * from t1 where e = 1; -- 没有走索引
explain select * from t1 where e = '1'; -- 走了索引
explain select * from t1 where a = 1; -- 走了索引
explain select * from t1 where a = '1'; -- 走了索引
```