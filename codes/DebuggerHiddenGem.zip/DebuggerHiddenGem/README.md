A class that I used for my demo at [20 years
of IntelliJ IDEA conference](https://www.jetbrains.com/lp/intellijidea-20-anniversary/)

Turn on `Settings | Editor | General | Appearance - Render Documentation Comments`

![alt text](img2.png)